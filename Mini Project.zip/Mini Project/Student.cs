﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace ConsoleApplication2
{
    class Student : Person
    {
        private void Eat()
        {
        }
        private void Sleep()
        {

        }
        private void ProgramCode()
        {

        }
        private void BunkClass()
        {

        }
    }
}
