﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Teacher : Person
    {
    public string Position { get; set; }
        
        public void Teach()
        {

        }
        public void Instruct()
        {

        }
        public void Demonstrate()
        {

        }
    }
}
