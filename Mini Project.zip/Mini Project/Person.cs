﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Person 
    {
    public string Name { get; set; }
    public int Age { get; set; }
    public string Gender { get; set; }
    public string Course { get; set; }
    public string AssignedArea { get; set; }
    public string Email { get; set; }


    private void Hair() 
     { 
     }
    private void Eyes()
    {

    }
    private void Nose()
    {

    }
    private void Body()
    {

    }










    }
}
