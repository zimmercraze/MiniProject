﻿using ConsoleApplication2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mini_Project
{
    class Program
    {
        static void Main(string[] args)
        {
            //Student Profile
            Student student = new Student();
            student.Name = "Ulyses Lad";
            student.Age = 20;
            student.Gender = "Male";
            student.Course = "BSIT-2";
            student.AssignedArea = "Law Library";
            student.Email = "zimmercraze@yahoo.com";

            //Teacher Profile
            Teacher teacher = new Teacher();
            teacher.Name = "Anne C. Jumamil";
            teacher.Age = 35;
            teacher.Gender = "Female";
            teacher.AssignedArea = "Law Library";
            teacher.Position = " Chief Librarian";
            teacher.Email = "AnneJumamil@yahoo.com";



            int Ulyses = 1;
            string input;
            for (int i = 0; i < Ulyses; i++)
            {
                Console.Write("Show GOE Scholar Profile? Yes/No?:");
                input = Console.ReadLine();
                if (input == "Yes")
                {
                    Console.Clear();
                    Console.WriteLine("Your Student Profile");
                    Console.WriteLine("Name: " + student.Name);
                    Console.WriteLine("Age: " + student.Age);
                    Console.WriteLine("Gender: " + student.Gender);
                    Console.WriteLine("Course: " + student.Course);
                    Console.WriteLine("AssignedArea: " + student.AssignedArea);
                    Console.WriteLine("Email: " + student.Email);

                    int Lad = 1;

                    for (int j = 0; j < Lad; j++)
                    {
                        Console.Write("\nShow Supervisor Profile? Yes/No?: ");
                        input = Console.ReadLine();
                        if (input == "Yes")
                        {
                    Console.Clear();
                    Console.WriteLine("Your Teacher Profile");
                    Console.WriteLine("Name: " + teacher.Name);
                    Console.WriteLine("Age: " + teacher.Age);
                    Console.WriteLine("Gender: " + teacher.Gender);
                    Console.WriteLine("Department: " + teacher.AssignedArea);
                    Console.WriteLine("Salary: " + teacher.Position);
                    Console.WriteLine("Email: " + teacher.Email);
                        }

                        else if (input == "No")
                        {
                        }
                        else
                        {
                            Lad++;
                        }
                    }
                }
                else if (input == "No")
                {
                }

                else
                {
                    Ulyses++;
                }
            }
        }
    }
}
   
